﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMOryGame
{
    public class MemoryCard : PictureBox
    {
        public int KépSzám { get; set; }

        public MemoryCard(int sor, int oszlop, int KépSzám)
        {
            this.KépSzám = KépSzám;
            Height = 128;
            Width = 128;
            Left = oszlop * 140;
            Top = sor * 140;

            Felforditva = false;
        }


        private bool felforditva;

        public bool Felforditva
        {
            get { return felforditva; }
            set { 
                felforditva = value;
                if (felforditva)
                {
                    Load($"kepek/nagy/{KépSzám}@2x.png");
                }
                else
                {
                    Load($"kepek/nagy/card_back@2x.png");
                }
            
            }
        }


    }
}
