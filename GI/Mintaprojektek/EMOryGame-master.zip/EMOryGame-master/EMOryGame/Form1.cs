﻿namespace EMOryGame
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            BackgroundImage = Bitmap.FromFile("kepek/bg@2x.png");
            Width = BackgroundImage.Width;
            Height = BackgroundImage.Height;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;

            var t = Keverés(16);

            int k = 0;
            for (int s = 0; s < 4; s++)
            {
                for (int o = 0; o < 4; o++)
                {
                    MemoryCard mc = new MemoryCard(s, o, t[k]);
                    Controls.Add(mc);
                    k++;
                    mc.Click += Mc_Click;
                }
            }
        }

        MemoryCard elsőKártya;
        MemoryCard másodikKártya;
        private void Mc_Click(object? sender, EventArgs e)
        {
            MemoryCard mostaniKártya = (MemoryCard)sender;

            if (elsőKártya==null &&  másodikKártya == null)
            {
                //Most fordítottuk el a "Fel" az első kártyáját.
                elsőKártya = mostaniKártya;
                elsőKártya.Felforditva = true;
                return;
            }

            if (elsőKártya!=null && másodikKártya==null)
            {
                //Amikor az első kártya mellé fölfordítottuk a második kártyát?
                másodikKártya = mostaniKártya;
                másodikKártya.Felforditva = true;

                if (elsőKártya.KépSzám==másodikKártya.KépSzám)
                {
                    elsőKártya.Visible = false;
                    másodikKártya.Visible = false;
                }
                return;
            }

            if (elsőKártya!=null && másodikKártya!=null)
            {
                //Fordítsd mind a két kártyát, és az utoljára megkartított lesz az első kártya.
                elsőKártya.Felforditva = false;
                másodikKártya.Felforditva =false;
                elsőKártya = mostaniKártya;
                elsőKártya.Felforditva = true;
                másodikKártya = null;

            }

            int a = 13;
            int b = a;
            b++;


            Button c = new Button();
            Button d = c;
            d.Text = ":)";



        }

        int[] Keverés(int kártyaszám)
        {
            int[] tömb = new int[kártyaszám];
            for (int i = 0; i < kártyaszám / 2; i++)
            {
                tömb[i] = i + 1;
                tömb[i + kártyaszám / 2] = i + 1;
            }
            //keverés
            Random rnd = new Random();
            for (int i = 0; i < kártyaszám; i++)
            {
                int egyik = rnd.Next(kártyaszám);
                int másik = rnd.Next(kártyaszám);

                int köztes = tömb[egyik];
                tömb[egyik] = tömb[másik];
                tömb[másik] = köztes;



            }



            return tömb;
        }
    }
}
